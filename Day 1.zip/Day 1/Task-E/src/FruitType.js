import React from 'react'

function FruitType() {
  return (
    <div>
        <h2>Fruits:</h2>
        <ul>
            <li>Apples</li>
            <li>Blueberries</li>
            <li>Strawberries</li>
            <li>Bananas</li>
        </ul>
    </div>
  );
}
export default FruitType;