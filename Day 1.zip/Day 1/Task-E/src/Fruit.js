import FruitType from "./FruitType";
import React from 'react'

function Fruit() {
  return (
    <div><FruitType></FruitType></div>
  )
}
export default Fruit