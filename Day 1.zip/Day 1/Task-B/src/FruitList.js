import React from 'react'

function FruitList() {
    const FruitList = [
        {id:101, name:"Apples"},
        {id:102, name:"Blueberries"},
        {id:103, name:"Strawberries"},
        {id:104, name:"Bananas"}
    ]
    const Fruits = FruitList.map(
        (item) => {
                return(
                <li key={item.id}>{item.name}</li>
            );
        }
    )
    return (
        <div>
            <ol type='1'>
                {Fruits}
            </ol>
        </div>
    );
}
export default FruitList