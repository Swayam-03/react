import { render } from "@testing-library/react";
import React, { useState } from "react";

function MovieList(props){

    const [movie, setMovie] = useState({name: props.name, price: props.price});
    //setMovie({name: "Inception", price: 120});

    function changeInfo(){
        setMovie({name: "Avengers", price:180});
    }

    return(
        <div>
            <h3>{movie.name}</h3>
            <h4>{movie.price}</h4>
            <button onClick={changeInfo}>Click to change</button>
        </div>
    );    
}
export default MovieList;