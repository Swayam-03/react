import React, { Component } from 'react'

export default class MovieList extends Component {
    constructor(props) {
        super(props)
        this.state = {
            movie: {
                name: "Default",
                price: 80
            }
        }
    }

    changeInfo(){
        this.setState({
            movie: {
                name: "Avengers",
                price: 180
            }
        })
    }

    render() {
        return (
        <div>
            <h3>{this.state.movie.name}</h3>
            <h4>{this.state.movie.price}</h4>
            <button onClick={this.changeInfo.bind(this)}>Click to change</button>
        </div>
        );
    }
}
